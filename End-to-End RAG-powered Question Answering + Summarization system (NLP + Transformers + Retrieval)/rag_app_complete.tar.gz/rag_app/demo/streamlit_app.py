"""
Streamlit frontend for RAG Question-Answering System.
Provides a user-friendly interface for document upload and querying.
"""

import streamlit as st
import requests
import json
import os
import tempfile
from typing import List, Dict, Any
import time

# Configure Streamlit page
st.set_page_config(
    page_title="RAG Q&A System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API Configuration
API_BASE_URL = "http://localhost:8001"

def check_api_health():
    """Check if the API is running and healthy."""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return response.status_code == 200, response.json() if response.status_code == 200 else None
    except requests.exceptions.RequestException:
        return False, None

def upload_documents(files):
    """Upload documents to the API."""
    try:
        files_data = []
        for file in files:
            files_data.append(('files', (file.name, file.getvalue(), file.type)))
        
        response = requests.post(f"{API_BASE_URL}/ingest", files=files_data, timeout=30)
        return response.status_code == 200, response.json() if response.status_code == 200 else response.text
    except requests.exceptions.RequestException as e:
        return False, str(e)

def query_documents(question: str, max_results: int = 5, use_compression: bool = False):
    """Query the document collection."""
    try:
        payload = {
            "question": question,
            "max_results": max_results,
            "use_compression": use_compression
        }
        response = requests.post(f"{API_BASE_URL}/query", json=payload, timeout=30)
        return response.status_code == 200, response.json() if response.status_code == 200 else response.text
    except requests.exceptions.RequestException as e:
        return False, str(e)

def summarize_documents(query: str = None, max_documents: int = 10):
    """Generate a summary of documents."""
    try:
        payload = {
            "max_documents": max_documents
        }
        if query:
            payload["query"] = query
        
        response = requests.post(f"{API_BASE_URL}/summarize", json=payload, timeout=30)
        return response.status_code == 200, response.json() if response.status_code == 200 else response.text
    except requests.exceptions.RequestException as e:
        return False, str(e)

def main():
    """Main Streamlit application."""
    
    # Header
    st.title("🤖 RAG Question-Answering System")
    st.markdown("Upload documents and ask questions to get AI-powered answers with source citations.")
    
    # Check API health
    api_healthy, health_data = check_api_health()
    
    if not api_healthy:
        st.error("⚠️ Backend API is not running. Please start the FastAPI server first.")
        st.code("cd src/api && python app.py")
        st.stop()
    
    # Display system status
    with st.sidebar:
        st.header("📊 System Status")
        if health_data:
            st.success("✅ API Connected")
            st.write(f"**Status:** {health_data.get('status', 'Unknown')}")
            st.write(f"**Documents Loaded:** {health_data.get('documents_loaded', 0)}")
            st.write(f"**Index Ready:** {'✅' if health_data.get('index_ready') else '❌'}")
        else:
            st.warning("⚠️ Could not get system status")
    
    # Main interface tabs
    tab1, tab2, tab3 = st.tabs(["📁 Upload Documents", "❓ Ask Questions", "📝 Summarize"])
    
    with tab1:
        st.header("📁 Document Upload")
        st.markdown("Upload PDF, TXT, or Markdown files to build your knowledge base.")
        
        uploaded_files = st.file_uploader(
            "Choose files",
            type=['pdf', 'txt', 'md'],
            accept_multiple_files=True,
            help="Supported formats: PDF, TXT, MD"
        )
        
        if uploaded_files:
            st.write(f"Selected {len(uploaded_files)} file(s):")
            for file in uploaded_files:
                st.write(f"- {file.name} ({file.size} bytes)")
            
            if st.button("🚀 Upload and Process", type="primary"):
                with st.spinner("Uploading and processing documents..."):
                    success, result = upload_documents(uploaded_files)
                    
                    if success:
                        st.success("✅ Documents uploaded successfully!")
                        st.json(result)
                        
                        # Show processing status
                        st.info("📊 Processing documents in background. This may take a few minutes.")
                        
                        # Auto-refresh status
                        progress_placeholder = st.empty()
                        for i in range(30):  # Check for 30 seconds
                            time.sleep(2)
                            _, current_health = check_api_health()
                            if current_health and current_health.get('index_ready'):
                                progress_placeholder.success("✅ Documents processed and indexed!")
                                st.rerun()
                                break
                            progress_placeholder.info(f"⏳ Processing... ({i*2}s)")
                        else:
                            progress_placeholder.warning("⚠️ Processing is taking longer than expected. Please check back later.")
                    else:
                        st.error(f"❌ Upload failed: {result}")
    
    with tab2:
        st.header("❓ Ask Questions")
        
        if not health_data or not health_data.get('index_ready'):
            st.warning("⚠️ Please upload documents first before asking questions.")
        else:
            st.markdown("Ask questions about your uploaded documents and get AI-powered answers with source citations.")
            
            # Question input
            question = st.text_area(
                "Enter your question:",
                placeholder="What is machine learning?",
                height=100
            )
            
            # Advanced options
            with st.expander("⚙️ Advanced Options"):
                max_results = st.slider("Maximum results", 1, 10, 5)
                use_compression = st.checkbox("Use compression retriever", help="May improve relevance but slower")
            
            if st.button("🔍 Get Answer", type="primary", disabled=not question.strip()):
                with st.spinner("Searching documents and generating answer..."):
                    success, result = query_documents(question, max_results, use_compression)
                    
                    if success:
                        st.success("✅ Answer generated!")
                        
                        # Display answer
                        st.subheader("📝 Answer")
                        st.write(result['answer'])
                        
                        # Display confidence
                        confidence = result.get('confidence', 0)
                        st.metric("Confidence", f"{confidence:.1%}")
                        
                        # Display sources
                        if result.get('sources'):
                            st.subheader("📚 Sources")
                            for i, source in enumerate(result['sources'], 1):
                                with st.expander(f"Source {i}: {source['metadata'].get('source_document', 'Unknown')}"):
                                    st.write(source['content'])
                                    st.json(source['metadata'])
                        
                        # Display context used (if available)
                        if result.get('context_used'):
                            with st.expander("🔍 Context Used"):
                                st.text(result['context_used'])
                    else:
                        st.error(f"❌ Query failed: {result}")
    
    with tab3:
        st.header("📝 Document Summarization")
        
        if not health_data or not health_data.get('index_ready'):
            st.warning("⚠️ Please upload documents first before generating summaries.")
        else:
            st.markdown("Generate summaries of your document collection.")
            
            # Summary options
            summary_query = st.text_input(
                "Optional: Filter by topic",
                placeholder="machine learning",
                help="Leave empty to summarize all documents"
            )
            
            max_documents = st.slider("Maximum documents to summarize", 1, 20, 10)
            
            if st.button("📝 Generate Summary", type="primary"):
                with st.spinner("Generating summary..."):
                    success, result = summarize_documents(summary_query if summary_query.strip() else None, max_documents)
                    
                    if success:
                        st.success("✅ Summary generated!")
                        
                        # Display summary
                        st.subheader("📄 Summary")
                        st.write(result['summary'])
                        
                        # Display metadata
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Documents Processed", result['num_documents'])
                        with col2:
                            st.metric("Input Length", f"{result['input_length']} chars")
                    else:
                        st.error(f"❌ Summarization failed: {result}")
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: #666;'>
            Built with ❤️ using FastAPI, LangChain, FAISS, and Streamlit
        </div>
        """,
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()

