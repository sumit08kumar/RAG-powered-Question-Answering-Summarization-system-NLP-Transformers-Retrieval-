"""
FastAPI application for RAG system.
Provides endpoints for document ingestion and question answering.
"""

import os
import logging
import tempfile
from typing import List, Dict, Any, Optional
from pathlib import Path
import json

from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# Import our modules
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

try:
    from ingest import ingest_documents
    from retriever import create_retriever_from_chunks, LangChainRetriever
    from generator import create_generator, RAGGenerator
except ImportError as e:
    print(f"Warning: Could not import modules: {e}")
    ingest_documents = None
    create_retriever_from_chunks = None
    create_generator = None

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="RAG Question-Answering System",
    description="A Retrieval-Augmented Generation system for document Q&A and summarization",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables for system components
retriever: Optional[LangChainRetriever] = None
generator: Optional[RAGGenerator] = None
system_status = {
    "initialized": False,
    "documents_loaded": 0,
    "index_ready": False
}

# Pydantic models for API requests/responses
class QueryRequest(BaseModel):
    question: str
    max_results: int = 5
    use_compression: bool = False

class QueryResponse(BaseModel):
    answer: str
    confidence: float
    sources: List[Dict[str, Any]]
    context_used: Optional[str] = None

class SummarizeRequest(BaseModel):
    query: Optional[str] = None  # Optional query to filter documents
    max_documents: int = 10

class SummarizeResponse(BaseModel):
    summary: str
    num_documents: int
    input_length: int

class StatusResponse(BaseModel):
    status: str
    initialized: bool
    documents_loaded: int
    index_ready: bool
    message: str


@app.on_event("startup")
async def startup_event():
    """Initialize the system on startup."""
    global generator, system_status
    
    try:
        logger.info("Initializing RAG system...")
        
        # Initialize generator
        if create_generator is not None:
            generator = create_generator()
            logger.info("Generator initialized")
        
        system_status["initialized"] = True
        logger.info("RAG system startup completed")
        
    except Exception as e:
        logger.error(f"Failed to initialize system: {e}")
        system_status["initialized"] = False


@app.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint with basic information."""
    return {
        "message": "RAG Question-Answering System",
        "version": "1.0.0",
        "status": "running" if system_status["initialized"] else "initializing"
    }


@app.get("/health", response_model=StatusResponse)
async def health_check():
    """Health check endpoint."""
    return StatusResponse(
        status="healthy" if system_status["initialized"] else "initializing",
        initialized=system_status["initialized"],
        documents_loaded=system_status["documents_loaded"],
        index_ready=system_status["index_ready"],
        message="System is ready" if system_status["index_ready"] else "Upload documents to get started"
    )


@app.post("/ingest")
async def ingest_documents_endpoint(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...)
):
    """
    Ingest documents and build the vector index.
    
    Args:
        files: List of uploaded document files
        
    Returns:
        Status of the ingestion process
    """
    global retriever, system_status
    
    if not system_status["initialized"]:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")
    
    # Validate file types
    supported_extensions = {'.pdf', '.txt', '.md'}
    for file in files:
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in supported_extensions:
            raise HTTPException(
                status_code=400, 
                detail=f"Unsupported file type: {file_ext}. Supported: {supported_extensions}"
            )
    
    try:
        # Save uploaded files temporarily
        temp_files = []
        for file in files:
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=Path(file.filename).suffix)
            content = await file.read()
            temp_file.write(content)
            temp_file.close()
            temp_files.append(temp_file.name)
        
        # Process documents in background
        background_tasks.add_task(process_documents, temp_files, [f.filename for f in files])
        
        return {
            "message": f"Started processing {len(files)} documents",
            "files": [f.filename for f in files],
            "status": "processing"
        }
        
    except Exception as e:
        logger.error(f"Error in document ingestion: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process documents: {str(e)}")


async def process_documents(temp_file_paths: List[str], original_filenames: List[str]):
    """Background task to process documents and build index."""
    global retriever, system_status
    
    try:
        logger.info(f"Processing {len(temp_file_paths)} documents...")
        
        # Ingest documents
        if ingest_documents is not None:
            chunks = ingest_documents(temp_file_paths)
            logger.info(f"Created {len(chunks)} chunks from documents")
            
            # Create retriever with vector index
            if create_retriever_from_chunks is not None:
                retriever = create_retriever_from_chunks(
                    chunks, 
                    save_path="./vector_store"
                )
                
                system_status["documents_loaded"] = len(original_filenames)
                system_status["index_ready"] = True
                
                logger.info("Vector index created successfully")
            else:
                logger.error("create_retriever_from_chunks not available")
        else:
            logger.error("ingest_documents not available")
        
    except Exception as e:
        logger.error(f"Error processing documents: {e}")
        system_status["index_ready"] = False
    
    finally:
        # Clean up temporary files
        for temp_file in temp_file_paths:
            try:
                os.unlink(temp_file)
            except Exception as e:
                logger.warning(f"Failed to delete temp file {temp_file}: {e}")


@app.post("/query", response_model=QueryResponse)
async def query_documents(request: QueryRequest):
    """
    Query the document collection with a question.
    
    Args:
        request: Query request with question and parameters
        
    Returns:
        Generated answer with sources and confidence
    """
    global retriever, generator
    
    if not system_status["index_ready"]:
        raise HTTPException(
            status_code=400, 
            detail="No documents loaded. Please upload documents first using /ingest endpoint."
        )
    
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty")
    
    try:
        # Retrieve relevant documents
        retrieved_docs = retriever.retrieve_documents(
            request.question, 
            use_compression=request.use_compression
        )
        
        if not retrieved_docs:
            return QueryResponse(
                answer="I couldn't find any relevant information to answer your question.",
                confidence=0.0,
                sources=[]
            )
        
        # Limit number of documents
        retrieved_docs = retrieved_docs[:request.max_results]
        
        # Generate answer
        result = generator.answer_question(request.question, retrieved_docs)
        
        return QueryResponse(
            answer=result['answer'],
            confidence=result['confidence'],
            sources=result['sources'],
            context_used=result.get('context_used')
        )
        
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process query: {str(e)}")


@app.post("/summarize", response_model=SummarizeResponse)
async def summarize_documents(request: SummarizeRequest):
    """
    Generate a summary of documents.
    
    Args:
        request: Summarization request with optional query filter
        
    Returns:
        Generated summary with metadata
    """
    global retriever, generator
    
    if not system_status["index_ready"]:
        raise HTTPException(
            status_code=400, 
            detail="No documents loaded. Please upload documents first using /ingest endpoint."
        )
    
    try:
        if request.query:
            # Use query to filter relevant documents
            retrieved_docs = retriever.retrieve_documents(
                request.query, 
                use_compression=False
            )
        else:
            # Get all documents (limited by max_documents)
            # This is a simplified approach - in practice, you might want to implement
            # a method to get all documents from the vector store
            retrieved_docs = retriever.retrieve_documents(
                "summary of all content",  # Generic query
                use_compression=False
            )
        
        # Limit number of documents
        retrieved_docs = retrieved_docs[:request.max_documents]
        
        if not retrieved_docs:
            return SummarizeResponse(
                summary="No documents found to summarize.",
                num_documents=0,
                input_length=0
            )
        
        # Generate summary
        result = generator.summarize_documents(retrieved_docs)
        
        return SummarizeResponse(
            summary=result['summary'],
            num_documents=result['num_documents'],
            input_length=result['input_length']
        )
        
    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate summary: {str(e)}")


@app.get("/documents")
async def list_documents():
    """List information about loaded documents."""
    if not system_status["index_ready"]:
        return {"message": "No documents loaded", "documents": []}
    
    # This would need to be implemented based on how you store document metadata
    return {
        "message": f"{system_status['documents_loaded']} documents loaded",
        "documents_count": system_status['documents_loaded'],
        "index_ready": system_status['index_ready']
    }


if __name__ == "__main__":
    import uvicorn
    
    # Run the application
    uvicorn.run(
        "app:app",
        host="0.0.0.0",  # Listen on all interfaces
        port=8000,
        reload=True,
        log_level="info"
    )

