"""
Document ingestion and preprocessing module for RAG system.
Handles PDF, text, and other document formats.
"""

import os
import logging
from typing import List, Dict, Any
from pathlib import Path
import pdfplumber
import pypdf
from pypdf import PdfReader

logger = logging.getLogger(__name__)


class DocumentIngester:
    """Handles document ingestion and preprocessing."""
    
    def __init__(self):
        self.supported_formats = ['.pdf', '.txt', '.md']
    
    def ingest_document(self, file_path: str) -> Dict[str, Any]:
        """
        Ingest a single document and return processed content.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            Dictionary containing processed content and metadata
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        if file_path.suffix.lower() not in self.supported_formats:
            raise ValueError(f"Unsupported file format: {file_path.suffix}")
        
        metadata = {
            'filename': file_path.name,
            'file_path': str(file_path),
            'file_size': file_path.stat().st_size,
            'file_type': file_path.suffix.lower()
        }
        
        if file_path.suffix.lower() == '.pdf':
            content = self._extract_pdf_content(file_path)
        elif file_path.suffix.lower() in ['.txt', '.md']:
            content = self._extract_text_content(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_path.suffix}")
        
        return {
            'content': content,
            'metadata': metadata
        }
    
    def _extract_pdf_content(self, file_path: Path) -> str:
        """Extract text content from PDF file."""
        try:
            # Try pdfplumber first (better for complex layouts)
            with pdfplumber.open(file_path) as pdf:
                text_content = []
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_content.append(page_text)
                return '\n\n'.join(text_content)
        except Exception as e:
            logger.warning(f"pdfplumber failed for {file_path}, trying pypdf: {e}")
            
            # Fallback to pypdf
            try:
                reader = PdfReader(file_path)
                text_content = []
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_content.append(page_text)
                return '\n\n'.join(text_content)
            except Exception as e:
                logger.error(f"Failed to extract PDF content from {file_path}: {e}")
                raise
    
    def _extract_text_content(self, file_path: Path) -> str:
        """Extract content from text files."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError:
            # Try with different encoding
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text content."""
        # Remove excessive whitespace
        text = ' '.join(text.split())
        
        # Remove common artifacts
        text = text.replace('\x00', '')  # Remove null characters
        text = text.replace('\ufffd', '')  # Remove replacement characters
        
        return text.strip()
    
    def chunk_text(self, text: str, chunk_size: int = 512, overlap: int = 128) -> List[Dict[str, Any]]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Input text to chunk
            chunk_size: Maximum size of each chunk (in characters)
            overlap: Number of characters to overlap between chunks
            
        Returns:
            List of chunk dictionaries with content and metadata
        """
        if len(text) <= chunk_size:
            return [{'content': text, 'chunk_id': 0, 'start_pos': 0, 'end_pos': len(text)}]
        
        chunks = []
        start = 0
        chunk_id = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at sentence boundaries
            if end < len(text):
                # Look for sentence endings within the last 100 characters
                sentence_end = text.rfind('.', start, end)
                if sentence_end > start + chunk_size - 100:
                    end = sentence_end + 1
                else:
                    # Look for paragraph breaks
                    para_break = text.rfind('\n\n', start, end)
                    if para_break > start + chunk_size - 200:
                        end = para_break + 2
            
            chunk_content = text[start:end].strip()
            if chunk_content:
                chunks.append({
                    'content': chunk_content,
                    'chunk_id': chunk_id,
                    'start_pos': start,
                    'end_pos': end
                })
                chunk_id += 1
            
            # Move start position with overlap
            start = max(start + 1, end - overlap)
            
            # Prevent infinite loop
            if start >= len(text):
                break
        
        return chunks


def ingest_documents(document_paths: List[str]) -> List[Dict[str, Any]]:
    """
    Ingest multiple documents and return processed chunks.
    
    Args:
        document_paths: List of paths to document files
        
    Returns:
        List of processed document chunks with metadata
    """
    ingester = DocumentIngester()
    all_chunks = []
    
    for doc_path in document_paths:
        try:
            logger.info(f"Processing document: {doc_path}")
            doc_data = ingester.ingest_document(doc_path)
            
            # Clean the text
            cleaned_text = ingester.clean_text(doc_data['content'])
            
            # Chunk the text
            chunks = ingester.chunk_text(cleaned_text)
            
            # Add document metadata to each chunk
            for chunk in chunks:
                chunk['document_metadata'] = doc_data['metadata']
                chunk['source_document'] = doc_data['metadata']['filename']
            
            all_chunks.extend(chunks)
            logger.info(f"Created {len(chunks)} chunks from {doc_path}")
            
        except Exception as e:
            logger.error(f"Failed to process document {doc_path}: {e}")
            continue
    
    return all_chunks


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Test with a sample document
    sample_docs = ["sample.pdf", "sample.txt"]  # Add your test documents here
    chunks = ingest_documents(sample_docs)
    
    print(f"Processed {len(chunks)} chunks from {len(sample_docs)} documents")
    for i, chunk in enumerate(chunks[:3]):  # Show first 3 chunks
        print(f"\nChunk {i}:")
        print(f"Content: {chunk['content'][:200]}...")
        print(f"Source: {chunk['source_document']}")

