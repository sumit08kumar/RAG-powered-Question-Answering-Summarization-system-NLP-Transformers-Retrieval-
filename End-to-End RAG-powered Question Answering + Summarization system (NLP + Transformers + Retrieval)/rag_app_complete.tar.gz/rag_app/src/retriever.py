"""
Retrieval module using LangChain for RAG system.
Integrates FAISS vector store with LangChain retrievers.
"""

import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

# Import will be available after installation completes
try:
    from langchain.vectorstores import FAISS
    from langchain.embeddings import HuggingFaceEmbeddings
    from langchain.schema import Document
    from langchain.retrievers import ContextualCompressionRetriever
    from langchain.retrievers.document_compressors import LLMChainExtractor
    from langchain.llms import HuggingFacePipeline
    from transformers import pipeline
except ImportError:
    print("Warning: LangChain and related packages not yet installed")
    FAISS = None
    HuggingFaceEmbeddings = None
    Document = None

logger = logging.getLogger(__name__)


class LangChainRetriever:
    """LangChain-based retriever for RAG system."""
    
    def __init__(self, 
                 embedding_model: str = 'all-mpnet-base-v2',
                 vector_store_path: str = None):
        """
        Initialize the LangChain retriever.
        
        Args:
            embedding_model: Name of the embedding model
            vector_store_path: Path to saved vector store
        """
        self.embedding_model_name = embedding_model
        self.vector_store_path = vector_store_path
        self.embeddings = None
        self.vector_store = None
        self.retriever = None
        self.compression_retriever = None
        
        # Initialize embeddings if available
        if HuggingFaceEmbeddings is not None:
            self._initialize_embeddings()
    
    def _initialize_embeddings(self):
        """Initialize the embedding model."""
        try:
            logger.info(f"Initializing embeddings with model: {self.embedding_model_name}")
            self.embeddings = HuggingFaceEmbeddings(
                model_name=self.embedding_model_name,
                model_kwargs={'device': 'cpu'},  # Use CPU for compatibility
                encode_kwargs={'normalize_embeddings': True}
            )
        except Exception as e:
            logger.error(f"Failed to initialize embeddings: {e}")
            raise
    
    def create_vector_store_from_chunks(self, chunks: List[Dict[str, Any]]) -> None:
        """
        Create a FAISS vector store from document chunks.
        
        Args:
            chunks: List of document chunks with content and metadata
        """
        if self.embeddings is None:
            raise RuntimeError("Embeddings not initialized")
        
        if not chunks:
            logger.warning("No chunks provided to create vector store")
            return
        
        # Convert chunks to LangChain Documents
        documents = []
        for chunk in chunks:
            doc = Document(
                page_content=chunk['content'],
                metadata={
                    'chunk_id': chunk.get('chunk_id', 0),
                    'source_document': chunk.get('source_document', 'unknown'),
                    'start_pos': chunk.get('start_pos', 0),
                    'end_pos': chunk.get('end_pos', 0),
                    **chunk.get('document_metadata', {})
                }
            )
            documents.append(doc)
        
        logger.info(f"Creating FAISS vector store from {len(documents)} documents")
        
        # Create FAISS vector store
        self.vector_store = FAISS.from_documents(
            documents=documents,
            embedding=self.embeddings
        )
        
        logger.info("Vector store created successfully")
    
    def save_vector_store(self, path: str = None):
        """Save the vector store to disk."""
        if self.vector_store is None:
            raise RuntimeError("No vector store to save")
        
        save_path = path or self.vector_store_path or "langchain_faiss_store"
        self.vector_store.save_local(save_path)
        logger.info(f"Vector store saved to {save_path}")
    
    def load_vector_store(self, path: str = None):
        """Load a vector store from disk."""
        if self.embeddings is None:
            raise RuntimeError("Embeddings not initialized")
        
        load_path = path or self.vector_store_path or "langchain_faiss_store"
        
        if not Path(load_path).exists():
            raise FileNotFoundError(f"Vector store not found at {load_path}")
        
        self.vector_store = FAISS.load_local(load_path, self.embeddings)
        logger.info(f"Vector store loaded from {load_path}")
    
    def get_retriever(self, search_type: str = "similarity", k: int = 5) -> Any:
        """
        Get a basic retriever from the vector store.
        
        Args:
            search_type: Type of search ("similarity" or "mmr")
            k: Number of documents to retrieve
            
        Returns:
            LangChain retriever object
        """
        if self.vector_store is None:
            raise RuntimeError("Vector store not initialized")
        
        self.retriever = self.vector_store.as_retriever(
            search_type=search_type,
            search_kwargs={"k": k}
        )
        
        return self.retriever
    
    def get_compression_retriever(self, 
                                llm_model: str = "google/flan-t5-base",
                                k: int = 10,
                                compressed_k: int = 5) -> Any:
        """
        Get a compression retriever that filters and compresses retrieved documents.
        
        Args:
            llm_model: Model to use for compression
            k: Number of documents to initially retrieve
            compressed_k: Number of documents to return after compression
            
        Returns:
            Contextual compression retriever
        """
        if self.vector_store is None:
            raise RuntimeError("Vector store not initialized")
        
        try:
            # Create base retriever
            base_retriever = self.vector_store.as_retriever(
                search_kwargs={"k": k}
            )
            
            # Create LLM for compression
            hf_pipeline = pipeline(
                "text2text-generation",
                model=llm_model,
                max_length=512,
                temperature=0.1
            )
            llm = HuggingFacePipeline(pipeline=hf_pipeline)
            
            # Create compressor
            compressor = LLMChainExtractor.from_llm(llm)
            
            # Create compression retriever
            self.compression_retriever = ContextualCompressionRetriever(
                base_compressor=compressor,
                base_retriever=base_retriever
            )
            
            return self.compression_retriever
            
        except Exception as e:
            logger.warning(f"Failed to create compression retriever: {e}")
            # Fallback to basic retriever
            return self.get_retriever(k=compressed_k)
    
    def retrieve_documents(self, query: str, use_compression: bool = False) -> List[Document]:
        """
        Retrieve relevant documents for a query.
        
        Args:
            query: Search query
            use_compression: Whether to use compression retriever
            
        Returns:
            List of relevant documents
        """
        if use_compression and self.compression_retriever is not None:
            retriever = self.compression_retriever
        elif self.retriever is not None:
            retriever = self.retriever
        else:
            retriever = self.get_retriever()
        
        try:
            documents = retriever.get_relevant_documents(query)
            logger.info(f"Retrieved {len(documents)} documents for query: {query[:50]}...")
            return documents
        except Exception as e:
            logger.error(f"Error retrieving documents: {e}")
            return []
    
    def search_similarity(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """
        Perform similarity search and return results with scores.
        
        Args:
            query: Search query
            k: Number of results to return
            
        Returns:
            List of search results with scores and metadata
        """
        if self.vector_store is None:
            raise RuntimeError("Vector store not initialized")
        
        try:
            # Perform similarity search with scores
            results = self.vector_store.similarity_search_with_score(query, k=k)
            
            formatted_results = []
            for i, (doc, score) in enumerate(results):
                result = {
                    'rank': i + 1,
                    'score': float(score),
                    'content': doc.page_content,
                    'metadata': doc.metadata
                }
                formatted_results.append(result)
            
            return formatted_results
            
        except Exception as e:
            logger.error(f"Error in similarity search: {e}")
            return []


def create_retriever_from_chunks(chunks: List[Dict[str, Any]], 
                               embedding_model: str = 'all-mpnet-base-v2',
                               save_path: str = None) -> LangChainRetriever:
    """
    Create a LangChain retriever from document chunks.
    
    Args:
        chunks: List of document chunks
        embedding_model: Embedding model name
        save_path: Path to save the vector store
        
    Returns:
        Configured LangChainRetriever instance
    """
    retriever = LangChainRetriever(
        embedding_model=embedding_model,
        vector_store_path=save_path
    )
    
    # Create vector store from chunks
    retriever.create_vector_store_from_chunks(chunks)
    
    # Save if path provided
    if save_path:
        retriever.save_vector_store(save_path)
    
    return retriever


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Sample chunks for testing
    sample_chunks = [
        {
            'content': 'Machine learning is a subset of artificial intelligence that focuses on algorithms.',
            'chunk_id': 0,
            'source_document': 'ml_guide.txt'
        },
        {
            'content': 'Deep learning uses neural networks with multiple layers to learn complex patterns.',
            'chunk_id': 1,
            'source_document': 'dl_guide.txt'
        },
        {
            'content': 'Natural language processing enables computers to understand human language.',
            'chunk_id': 2,
            'source_document': 'nlp_guide.txt'
        }
    ]
    
    try:
        # Create retriever
        retriever = create_retriever_from_chunks(sample_chunks)
        
        # Test retrieval
        query = "What is machine learning?"
        results = retriever.search_similarity(query, k=2)
        
        print(f"Search results for: {query}")
        for result in results:
            print(f"Score: {result['score']:.3f}")
            print(f"Content: {result['content']}")
            print(f"Source: {result['metadata'].get('source_document', 'unknown')}")
            print("---")
            
    except Exception as e:
        print(f"Error (expected if dependencies not installed): {e}")

